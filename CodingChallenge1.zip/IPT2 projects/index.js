const markMass = prompt('Enter Mark\'s Mass(kg)',0),
      markHeight = prompt('Enter Mark\'s Height(m)',0),
      johnMass = prompt('Enter John\'s Mass(kg)',0),
      johnHeight = prompt('Enter John\'s Height(m)',0);

let result;

result = `
        <ul>
            <li>Mark's Mass: ${markMass} kg</li>
            <li>Mark's Height: ${markHeight} m</li>
            <li>John's Mass: ${johnMass} kg</li>
            <li>John's Height: ${johnHeight} m</li><br>
            <input type = "button" onclick = "shw()" value = "Show BMI"></input>
        </ul>
    `;
    function shw(){
        alert("Mark's BMI: "+markBMI(markMass, markHeight)+"\n"+"John's BMI: "+johnBMI(johnMass, johnHeight))

        if(markBMI>johnBMI) {
            alert("Mark's BMI is greater than John's BMI");
        }
        else if (johnBMI>markBMI) {
            alert("John's BMI is greater than Mark's BMI");
        }
        else {
            alert("Mark's and John's BMI are the same");
        }
    }

    function markBMI(markMass, markHeight) {
        return markMass / (markHeight * markHeight);
    }
    function johnBMI(johnMass, johnHeight) {
        return johnMass / (johnHeight * johnHeight);
    }

let res = document.querySelector('#res');
res.innerHTML = result;